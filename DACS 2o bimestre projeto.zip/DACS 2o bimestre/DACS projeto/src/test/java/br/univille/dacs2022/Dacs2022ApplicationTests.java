package br.univille.dacs2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dacs2022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
